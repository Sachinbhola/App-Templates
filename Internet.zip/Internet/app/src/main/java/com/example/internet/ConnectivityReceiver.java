package com.example.internet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.example.internet.Network.NetworkUtilClass;

public class ConnectivityReceiver extends BroadcastReceiver {

    boolean status;
    @Override
    public void onReceive(Context context, Intent intent) {
        String message = NetworkUtilClass.checkConnectivity(context);
        if(message.isEmpty() || message=="0"){
            status = false;
        }
        else{
            status = true;
        }

        MainActivity.dialog(status);
    }

}
