package com.example.internet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private BroadcastReceiver Receiver = new ConnectivityReceiver();

    public static Button check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        check=findViewById(R.id.btn_no_internet);
        broadcastIntent();


        check.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        BottomSheetDialog bottomsheet = new BottomSheetDialog();
                        bottomsheet.show(getSupportFragmentManager(),"message");
                    }
                }
        );

    }

    public static void dialog(boolean result){
        if(result){
            check.setText("hurray");
        }
        else{
            check.setText("No internet");
        }
    }

    private void broadcastIntent() {
        registerReceiver(Receiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

    }
    protected void onPause() {
        super.onPause();
        unregisterReceiver(Receiver);
    }
}