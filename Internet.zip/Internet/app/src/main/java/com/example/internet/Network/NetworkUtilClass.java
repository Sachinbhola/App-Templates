package com.example.internet.Network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

public class NetworkUtilClass {

    public static String checkConnectivity(Context context){

        String status = null;
        ConnectivityManager manager = (ConnectivityManager)context.getSystemService(context.CONNECTIVITY_SERVICE);
        NetworkInfo info = manager.getActiveNetworkInfo();
        if(info != null && info.getDetailedState()== NetworkInfo.DetailedState.CONNECTED){

            if(info.getType() == ConnectivityManager.TYPE_WIFI){
                status = "1";
                Toast.makeText(context.getApplicationContext(),"internet hai!",Toast.LENGTH_LONG).show();
                return status;
            }
            else if(info.getType() == ConnectivityManager.TYPE_MOBILE){
                status = "1";
                Toast.makeText(context.getApplicationContext(),"internet hai!",Toast.LENGTH_LONG).show();
                return status;
            }


        }else{
            Toast.makeText(context.getApplicationContext(),"error!",Toast.LENGTH_LONG).show();
            return status = "0";
        }


        return status;
    }
}
