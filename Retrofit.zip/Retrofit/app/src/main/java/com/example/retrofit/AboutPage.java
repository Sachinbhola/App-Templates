package com.example.retrofit;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.request.Request;
import com.example.retrofit.models.ParentProfileDetails;
import com.example.retrofit.models.ProfileData;
import com.example.retrofit.models.ProfileDetails;
import com.example.retrofit.models.ProfileRequestModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AboutPage extends AppCompatActivity {

    List<ProfileDetails> profileList = new ArrayList<ProfileDetails>();
    TextView tvFollowersCount;
    TextView tvFollowingCount;
    TextView tvStatus;
    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<ProfileDetails> profileDataList= new ArrayList<ProfileDetails>();
    ProfileData profileData = new ProfileData();
    ParentProfileDetails parentList = new ParentProfileDetails();
    private static Context context ;
    ProfileRequestModel requestModel;
    private static Context mContext;

//    public static Context getContext() {
//        return mContext;
//    }
//
//    public static void setContext(Context mContext) {
//        this.mContext = mContext;
//    }

    // ProfileDetails profileDetails=new ProfileDetails();
    //*** Avoid globals ***



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_page);


        tvFollowersCount=findViewById(R.id.tvTotalFollowers);
        tvFollowingCount=findViewById(R.id.tvTotalFollowing);
        tvStatus=findViewById(R.id.tvKnobeeContent);


        getData();

        postData();


        generateList(profileDataList);

    }

    private void getData() {

/*
        GetDataService service = RetrofitInstance.getRetrofitInstance().create(GetDataService.class);

        ProfileRequestModel profileRequestModel = new ProfileRequestModel();

        profileRequestModel.setUser_id("4256");
        profileRequestModel.setToken("$2y$10$gV74I22h2IinQRCt6bMNs.IlQEbEhjiHEkE91sECTfWnfkGLaGA2K");
        profileRequestModel.getRequestprofileUserId("1");

        Call<ParentProfileDetails> call = service.postProfileDetails(profileRequestModel);

        call.enqueue(new Callback<ParentProfileDetails>() {
            @Override
            public void onResponse(Call<ParentProfileDetails> call, Response<ParentProfileDetails> response) {

                if(response.body()!=null) {

                        profileDataList.addAll(response.body().getParentProfileDetailsList());


//                    tvFollowersCount.setText(response.body().getProfileData().getUserDetails().getFollowerCount());
//                    tvFollowingCount.setText(response.body().getProfileData().getUserDetails().getFollowingCount());
//                    tvStatus.setText(response.body().getProfileData().getUserDetails().getStatus());

                    // profileList.addAll(response.body().getProfileData());


                }
                else {
                    Toast.makeText(getApplicationContext(), "Null value received", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ParentProfileDetails> call, Throwable t) {
            }
        });
*/
    }

    private void postData() {
        GetDataService service = RetrofitInstance.getRetrofitInstance().create(GetDataService.class);


        ProfileRequestModel profileRequestModel = new ProfileRequestModel("1","$2y$10$gV74I22h2IinQRCt6bMNs.IlQEbEhjiHEkE91sECTfWnfkGLaGA2K","1");

//        profileRequestModel.setUser_id("4256");
//        profileRequestModel.setToken("$2y$10$gV74I22h2IinQRCt6bMNs.IlQEbEhjiHEkE91sECTfWnfkGLaGA2K");
//        profileRequestModel.setRequestprofileUserId("1");
//        service.postProfileDetails(profileDetails);

        Call<ProfileRequestModel> postCall = service.postProfileDetails(profileRequestModel);

        postCall.enqueue(new Callback<ProfileRequestModel>() {
            @Override
            public void onResponse(Call<ProfileRequestModel> call, Response<ProfileRequestModel> response) {
                Toast.makeText(getApplicationContext(), "Successfully added data", Toast.LENGTH_LONG).show(); //how to add data
            }

            @Override
            public void onFailure(Call<ProfileRequestModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Null value received", Toast.LENGTH_LONG).show();
            }
        });

    }

    public void generateList(List<ProfileDetails> pList){
        recyclerView = findViewById(R.id.rvPosts);
        adapter = new MyAdapter(this,profileDataList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(AboutPage.this);//Linear Layout Manager
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
    }

}