package com.example.retrofit;

import com.example.retrofit.models.ParentProfileDetails;
import com.example.retrofit.models.ProfileDetails;
import com.example.retrofit.models.ProfileRequestModel;
import com.example.retrofit.models.TvShow;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface GetDataService {

@GET("")
    Call<TvShow> getPopularTvShows();

@GET("development/test/users/getUserProfileDetails.json")
    Call<ParentProfileDetails> getProfileDetails();


@POST("development/test/users/getUserProfileDetails.json")
    Call<ProfileRequestModel> postProfileDetails(@Body ProfileRequestModel profileRequestModel);

}



