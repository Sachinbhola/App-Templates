package com.example.retrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.retrofit.models.TVShows;
import com.example.retrofit.models.TvShow;

import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<TVShows> tvShows = new ArrayList<>();
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn=findViewById(R.id.btnClick);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        GetDataService service = RetrofitInstance.getRetrofitInstance().create(GetDataService.class);
        Call<TvShow> call = service.getPopularTvShows();

        call.enqueue(new Callback<TvShow>() {
            @Override
            public void onResponse(Call<TvShow> call, Response<TvShow> response) {
                Integer pages = response.body().getTotal();
                Toast.makeText(MainActivity.this,pages.toString(),Toast.LENGTH_LONG).show();  //context?
                tvShows.addAll(response.body().getTv_shows());
            }

            @Override
            public void onFailure(Call<TvShow> call, Throwable t) {
            }
        });

    }

//    public void generateList(List<TVShows> movieList){
//        recyclerView = findViewById(R.id.rvMovie);
//        adapter = new MyAdapter(this,movieList);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(MainActivity.this);//Linear Layout Manager
//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setAdapter(adapter);
//    }


}