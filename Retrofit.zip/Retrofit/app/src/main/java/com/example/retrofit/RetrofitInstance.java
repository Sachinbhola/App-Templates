package com.example.retrofit;

import com.example.retrofit.models.ProfileRequestModel;
import com.example.retrofit.models.TvShow;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import okhttp3.logging.HttpLoggingInterceptor.Level;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitInstance {


    public static HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor().setLevel(Level.BODY);

    public static OkHttpClient okClient = new OkHttpClient.Builder().addInterceptor(loggingInterceptor).build();

    public static Retrofit retrofit;

    public static final String Base_URL="https://knobee.app/";

//    GetDataService dataService = retrofit.create(GetDataService.class);


    public static Retrofit getRetrofitInstance(){
        if(retrofit==null){
            retrofit =  new retrofit2.Retrofit.Builder()
                    .baseUrl(Base_URL)
                    .client(okClient)
                .addConverterFactory(GsonConverterFactory.create())
            .build();
        }
        return retrofit;
    }

    //Http logging interceptor

}
