package com.example.retrofit.models;

public class Education {

    private int id;
    private String college_name;
    private int type;


}
