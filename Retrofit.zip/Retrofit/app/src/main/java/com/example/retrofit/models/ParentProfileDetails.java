package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ParentProfileDetails {

    private List<ProfileDetails> parentProfileDetailsList;

    public List<ProfileDetails> getParentProfileDetailsList() {
        return parentProfileDetailsList;
    }

    public void setParentProfileDetailsList(List<ProfileDetails> parentProfileDetailsList) {
        this.parentProfileDetailsList = parentProfileDetailsList;
    }
}
