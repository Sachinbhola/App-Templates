package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ProfileData
{
    @SerializedName("UserDetails")
    private UserDetails userDetails;

    @SerializedName("gallery")
    private List<gallery> galleryList;

    @SerializedName("profileImages")
    private List<profileImages> profileImageList;

    @SerializedName("friendList")
    private List<friend> friendList;


    public UserDetails getUserDetails() {
        return userDetails;
    }

    public void setUserDetails(UserDetails userDetails) {
        this.userDetails = userDetails;
    }

    public List<gallery> getGalleryList() {
        return galleryList;
    }

    public void setGalleryList(List<gallery> galleryList) {
        this.galleryList = galleryList;
    }

    public List<profileImages> getProfileImageList() {
        return profileImageList;
    }

    public void setProfileImageList(List<profileImages> profileImageList) {
        this.profileImageList = profileImageList;
    }

    public List<friend> getFriendList() {
        return friendList;
    }

    public void setFriendList(List<friend> friendList) {
        this.friendList = friendList;
    }
}
