package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

public class ProfileDetails {


    private String status;

    private int code;

    private int message;

    @SerializedName("data")
    private ProfileData profileData;

    public ProfileData getProfileData() {
        return profileData;
    }

    public void setProfileData(ProfileData profileData) {
        this.profileData = profileData;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getMessage() {
        return message;
    }

    public void setMessage(int message) {
        this.message = message;
    }
}
