package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

public class ProfileRequestModel {

//      "requestprofileUserId": "1",
//              "token": "$2y$10$gV74I22h2IinQRCt6bMNs.IlQEbEhjiHEkE91sECTfWnfkGLaGA2K",
//              "user_id": "4256"



    @SerializedName("requestProfileUserId")
    private String requestprofileUserId;

    @SerializedName("token")
    private String token;

    @SerializedName("user_id")
    private String user_id;

    public ProfileRequestModel(String requestProfileUserId,String token,String user_id){
        this.requestprofileUserId=requestProfileUserId;
        this.token=token;
        this.user_id=user_id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getRequestprofileUserId() {
        return requestprofileUserId;
    }

    public void setRequestprofileUserId(String requestprofileUserId) {
        this.requestprofileUserId = requestprofileUserId;
    }
}
