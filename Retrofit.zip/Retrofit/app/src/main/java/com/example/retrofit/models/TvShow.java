package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TvShow {

    @SerializedName("total")
    private int total;

    @SerializedName("page")
    private int page;

    @SerializedName("tv_shows")
    private List<TVShows> tv_shows;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public List<TVShows> getTv_shows() {
        return tv_shows;
    }

    public void setTv_shows(List<TVShows> tv_shows) {
        this.tv_shows = tv_shows;
    }
}