package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class UserDetails {

    private boolean isFather;
    private boolean isMother;
    private boolean isSpouse;
    private int id;
    private String name;
    private String user_knobee_id;
    private String profilePic;
    private String gender;
    private boolean is_alive;
    private int hiveCount;
    private int friendCount;

    private String status;

    private String pincode;
    private String email;
    private int phncode;
    private String mobile;
    private int marital_status;
    private String user_uid;
    private int hive_id;
    private boolean is_verified;
    private boolean is_email_verified;

    private List<Education> educations;

    private List<Work> works;

    private Object city_id;
    private Object city_name;
    private Object state_id;
    private Object state_name;
    private Object country_id;
    private Object country_name;
    private int is_following;
    private int is_friend;
    private int is_hive_member;
    private boolean is_blocked;
    private int is_request_sent;
    private String member_since;
    private String lives_in;
    private String user_from;
    private Object dob;
    private Object age;
    private boolean hive_notification_status;
    private boolean mate_notification_status;
    private String show_profile_status;
    private String show_mate_status;
    private String show_media_status;
    private boolean chat_msg_notification_status;
    private boolean is_seen_status;
    private boolean enter_for_send_status;

    @SerializedName("feed_notification_id")
    private boolean feed_notofication_status;

    private int followerCount;
    private int followingCount;

    public int getFollowerCount() {
        return followerCount;
    }

    public void setFollowerCount(int followerCount) {
        this.followerCount = followerCount;
    }

    public int getFollowingCount() {
        return followingCount;
    }

    public void setFollowingCount(int followingCount) {
        this.followingCount = followingCount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
