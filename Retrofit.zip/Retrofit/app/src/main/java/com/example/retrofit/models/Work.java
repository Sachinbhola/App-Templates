package com.example.retrofit.models;

public class Work {
    private int id;
    private String company_name;
    private String position;

}
