package com.example.retrofit.models;

public class friend {

    private int is_mate_status;
    private int friendID;
    private String name;
    private String image;
    private String gender;
    private String status;
    private String city;
    private String country;
    private String last_lat;
    private String last_long;
    private boolean is_alive;
    private String user_knobee_id;
    private String last_post_date;
    private int common_frnd;
}
