package com.example.retrofit.models;

public class gallery{

    private int img_post_like_by_curr_user;
    private String image;
    private String imageCreatedDate;
    private int image_post_id;
    private String imageDescription;
    private int imageLikes;
    private int imageComment;

    public String getImageCreatedDate() {
        return imageCreatedDate;
    }

    public void setImageCreatedDate(String imageCreatedDate) {
        this.imageCreatedDate = imageCreatedDate;
    }
}
