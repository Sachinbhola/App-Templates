package com.example.retrofit.models;

import com.google.gson.annotations.SerializedName;

public class profileImages {
    @SerializedName("image")
    private String image;

    @SerializedName("date")
    private String imageCreatedDate;
}
