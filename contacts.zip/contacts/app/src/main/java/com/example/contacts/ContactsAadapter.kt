package com.example.contacts

import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.content.Intent.FLAG_DEBUG_LOG_RESOLUTION
import android.content.pm.PackageManager
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.math.log

class ContactsAdapter(private val contacts: MutableList<Person>) : RecyclerView.Adapter<ContactsAdapter.ViewHolder>(),Filterable {

    var searchList: MutableList<Person> =contacts

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val number: TextView = view.findViewById(R.id.tvNumber)
        val mail: TextView = view.findViewById(R.id.tvMail)
        val name: TextView = view.findViewById(R.id.tvName)
        var c1: View =view.findViewById(R.id.c1)
        var c2: View =view.findViewById(R.id.c2)
        var c3: View =view.findViewById(R.id.c3)
        var rvwaCard: View =view.findViewById(R.id.waCard)
        var rvsmsCard: View =view.findViewById(R.id.smsCard)
        var rvmailCard: View =view.findViewById(R.id.mailCard)


    }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contact, parent, false)

        return ViewHolder(view)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.name.text=contacts[position].name
        holder.mail.text=contacts[position].email
        holder.number.text=contacts[position].number

        holder.rvwaCard.setOnClickListener {
            var phoneNumber = contacts[position].number
            val intent=Intent(Intent.ACTION_VIEW)
            intent.setPackage("com.whatsapp")
            val data:String=phoneNumber

            intent.data=Uri.parse("http:wa.mne/$data")

                MyApp.applicationContext().startActivity(intent)
                intent.setFlags(FLAG_ACTIVITY_NEW_TASK)

        }
    }

    override fun getItemCount()= contacts.size

    override fun getFilter(): Filter {
        return object: Filter(){
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                    val str=constraint.toString()
                    if(str.isEmpty())
                    {
                        searchList=contacts
                    }
                    else
                    {
                        val result=ArrayList<String>()
                        for(i in contacts){
                            if (i.name.lowercase(Locale.ROOT).contains(str.lowercase(Locale.ROOT)))
                            {
                                result.add(i.name)
                            }
                        }
                        for(i in 0 until searchList.size)
                        {
                            searchList[i].name = result[i]

                        }
                    }
                    val filterResults = FilterResults()
                    filterResults.values = searchList

                    return filterResults

                }
            @Suppress("UNCHECKED_CAST")
            override fun publishResults(p0: CharSequence?, p1: FilterResults?) {

                searchList =if(p1?.values == null) {
                    contacts
                }else{
                     p1?.values as MutableList<Person>
                }
                notifyDataSetChanged()
            }
        }


    }

    fun clear(){
        searchList.clear()
    }



}