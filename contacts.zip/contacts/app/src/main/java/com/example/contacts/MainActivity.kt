package com.example.contacts

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {



    companion object {

        var person: Person = Person(
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone._ID
        )
        var values = listOf<Person>(person).toTypedArray()
        var list = mutableListOf<Person>()
        val adapter=ContactsAdapter(list)
        lateinit var searchView: SearchView


    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        searchView=findViewById(R.id.etPersonName)
        val searchtext:TextView=findViewById(R.id.searchText)



        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,Array(1){Manifest.permission.READ_CONTACTS},100)

        }
        else {

                GlobalScope.launch(Dispatchers.IO) {
                    readContacts()
                }
            }

        val contactsView: RecyclerView =findViewById<RecyclerView>(R.id.rvContacts)
        contactsView.adapter=adapter
        contactsView.layoutManager=LinearLayoutManager(this)



        fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
            onRequestPermissionsResult(requestCode, permissions, grantResults)
            if(requestCode==111 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                readContacts()
            }
        }

        if(values.isNotEmpty()){
            Toast.makeText(this,"success", Toast.LENGTH_LONG).show()
        }

        searchView.setOnClickListener {
            searchText.isVisible=false
        }



            searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

                override fun onQueryTextSubmit(p0: String?): Boolean {
                    adapter.filter.filter(p0)
                    return false
                }

                override fun onQueryTextChange(p0: String?): Boolean {


                    adapter.filter.filter(p0)

//                    val read= contentResolver.query(
//
//                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
//                        null,
//                        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
//                        Array(1){"%$p0%"},
//                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
//
//                    )
                    searchText.visibility = View.INVISIBLE
                    return false
                }
            })



    }


    private fun readContacts()
    {
        val read= contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            null,
            null,
            null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )

        if(read!!.count>0)
        {

            while(read.moveToNext())
            {
                var person :Person=Person("sachin","1","sacmail")

                person.name =read.getString(read.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                person.email=read.getString(read.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID))
                person.number=read.getString(read.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                list.add(person)
                }

            }



    }

    }






