package com.example.contacts

data class Person(var name : String, var number :String, var email : String){


}