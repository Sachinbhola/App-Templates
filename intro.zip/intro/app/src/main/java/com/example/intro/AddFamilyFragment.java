package com.example.intro;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class AddFamilyFragment extends Fragment {

View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_add_family, container, false);
        TextView tv3;

        tv3= view.findViewById(R.id.tvContent3);

        Spannable s1=new SpannableString("Invite your family here and have fun using KnoBee!");
        ForegroundColorSpan x=new ForegroundColorSpan(getResources().getColor(R.color.gold));
        s1.setSpan(x, 12, 18, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv3.setText(s1);
        return view;
    }

}