package com.example.intro;

import static android.widget.Toast.LENGTH_LONG;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class GetStarted extends Fragment {


    private View view;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_get_started, container, false);
        TextView tv1;

        tv1= view.findViewById(R.id.tvContent1);

        Spannable s1=new SpannableString("Thank you for joining KnoBee, world’s first family social network. Updates and new features are released frequently. Please help us to create a simple, beautiful, junk-free social network.");
        ForegroundColorSpan x=new ForegroundColorSpan(getResources().getColor(R.color.gold));
        s1.setSpan(x, 0, 28, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv1.setText(s1);
        return view;
    }

}