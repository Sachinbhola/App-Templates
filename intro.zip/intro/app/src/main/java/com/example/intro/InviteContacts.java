package com.example.intro;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class InviteContacts extends Fragment {

View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_invite_contacts, container, false);
        TextView tv2;

        tv2= view.findViewById(R.id.tvContent2);
        Spannable s1=new SpannableString("I’m so glad you decided to try out KnoBee. Let's get connected with your mates.");
        ForegroundColorSpan x=new ForegroundColorSpan(getResources().getColor(R.color.gold));
        s1.setSpan(x, 34, 41, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv2.setText(s1);
        return view;
    }
}