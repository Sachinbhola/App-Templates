package com.example.intro;

public enum ModelObject {

    STARTED(1, R.layout.fragment_get_started),
    FAMILY(2, R.layout.fragment_add_family),
    CONTACTS(3, R.layout.fragment_invite_contacts);

    private int mTitleResId;
    private int mLayoutResId;

    ModelObject(int titleResId, int layoutResId) {
        mTitleResId = titleResId;
        mLayoutResId = layoutResId;
    }

    public int getTitleResId() {
        return mTitleResId;
    }

    public int getLayoutResId() {
        return mLayoutResId;
    }

}
