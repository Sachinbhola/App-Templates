package com.example.sampletreeui;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    EditText text1;
    EditText text2;
    EditText text3;
    EditText text4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text1=findViewById(R.id.etPin1);
        text2=findViewById(R.id.etPin2);
        text3=findViewById(R.id.etPin3);
        text4=findViewById(R.id.etPin4);


        text1.requestFocus();
        text1.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                if(charSequence.length()>=1){
                    //text2.setText(null);
                    text2.setEnabled(true);
                    text2.requestFocus();
                    text1.setEnabled(false);

                }

            }

            @Override
            public void afterTextChanged(Editable editable) {
                text1.setOnKeyListener((view, i32, keyEvent) -> {
                    if (editable.length() == 0) {
                        if (i32 == KeyEvent.KEYCODE_DEL) {
                            // error message if no input is given
                        }
                    }
                    if (editable.length() == 1){
                        if(i32== KeyEvent.KEYCODE_0 || i32== KeyEvent.KEYCODE_1 || i32== KeyEvent.KEYCODE_2 || i32== KeyEvent.KEYCODE_3 ||i32== KeyEvent.KEYCODE_4 || i32== KeyEvent.KEYCODE_5 || i32== KeyEvent.KEYCODE_6 || i32== KeyEvent.KEYCODE_7 || i32== KeyEvent.KEYCODE_8 || i32== KeyEvent.KEYCODE_9) {
                            text2.setEnabled(true);
                            text2.requestFocus();
                            text1.setEnabled(false);

                        }
                    }

                    return false;
                });
            }
        });

        text2.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


                text2.setOnKeyListener((view, i3, keyEvent) -> {
                    if(charSequence.length()==0) {
                        if(i3 ==KeyEvent.KEYCODE_DEL){
                            text1.setEnabled(true);
                            text1.requestFocus();
                            text2.setEnabled(false);
                            text1.setSelection(text1.length());
                        }
                    }

                    return false;
                });

                if(charSequence.length()>=1){
                    //text3.setText(null);
                    text3.setEnabled(true);
                    text3.requestFocus();
                    text2.setEnabled(false);

                }


            }

            @Override
            public void afterTextChanged(Editable editable) {

                text2.setOnKeyListener((view, i32, keyEvent) -> {
                    if (editable.length() == 0) {
                        if (i32 == KeyEvent.KEYCODE_DEL) {
                            text1.setEnabled(true);
                            text1.requestFocus();
                            text2.setEnabled(false);

                        }
                    }
                    if (editable.length() == 1){
                        if(i32== KeyEvent.KEYCODE_0 || i32== KeyEvent.KEYCODE_1 || i32== KeyEvent.KEYCODE_2 || i32== KeyEvent.KEYCODE_3 ||i32== KeyEvent.KEYCODE_4 || i32== KeyEvent.KEYCODE_5 || i32== KeyEvent.KEYCODE_6 || i32== KeyEvent.KEYCODE_7 || i32== KeyEvent.KEYCODE_8 || i32== KeyEvent.KEYCODE_9) {
                            text3.setEnabled(true);
                            text3.requestFocus();
                            text2.setEnabled(false);
                        }
                    }

                    return false;
                });
            }
        });

        text3.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                text3.setOnKeyListener((view, i32, keyEvent) -> {
                    if (charSequence.length() == 0) {
                        if (i32 == KeyEvent.KEYCODE_DEL) {
                            text2.setEnabled(true);
                            text2.requestFocus();
                            text3.setEnabled(false);
                        }
                    }
                    return false;
                });
                if (charSequence.length() >= 1) {
                    text4.setEnabled(true);
                    text4.requestFocus();
                    text3.setEnabled(false);
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {
                text3.setOnKeyListener((view, i32, keyEvent) -> {
                    if (editable.length() == 0) {
                        if (i32 == KeyEvent.KEYCODE_DEL) {
                            text2.setEnabled(true);
                            text2.requestFocus();
                            text3.setEnabled(false);
                            text2.setSelection(text2.length());
                        }
                    }
                    if (text3.getText().length() == 1){
                        if(i32== KeyEvent.KEYCODE_0 || i32== KeyEvent.KEYCODE_1 || i32== KeyEvent.KEYCODE_2 || i32== KeyEvent.KEYCODE_3 ||i32== KeyEvent.KEYCODE_4 || i32== KeyEvent.KEYCODE_5 || i32== KeyEvent.KEYCODE_6 || i32== KeyEvent.KEYCODE_7 || i32== KeyEvent.KEYCODE_8 || i32== KeyEvent.KEYCODE_9) {
                            text4.setEnabled(true);
                            text4.requestFocus();
                            text3.setEnabled(false);
                        }
                    }
                    return false;
                });
            }

        });

        text4.addTextChangedListener(new TextWatcher() {

                @Override
                public void beforeTextChanged (CharSequence charSequence,int i, int i1, int i2){

                }

                @Override
                public void onTextChanged (CharSequence charSequence,int i, int i1, int i2){

                    text4.setOnKeyListener((view, i33, keyEvent) -> {

                        if (charSequence.length() == 0) {
                            if (i33 == KeyEvent.KEYCODE_DEL) {
                                text3.setEnabled(true);
                                text3.requestFocus();
                                text4.setEnabled(false);
                            }

                        }

                        if (charSequence.length() >= 1) {

                            if (text1.length() != 0 & text2.length() != 0 && text3.length() != 0) {
                                String s = "kotlin is better than java";
                                int d = Toast.LENGTH_LONG;
                                Context context = getApplicationContext();
                                Toast toast = Toast.makeText(context, s, d);
                                toast.show();
                            } else {
                                String s = "fill all fields";
                                int d = Toast.LENGTH_LONG;
                                Context context = getApplicationContext();
                                Toast toast = Toast.makeText(context, s, d);
                                toast.show();
                            }
                        }
                        return false;
                    });


                }

                @Override
                public void afterTextChanged (Editable editable){
                    text4.setOnKeyListener((view, i32, keyEvent) -> {
                        if (editable.length() == 0) {
                            if (i32 == KeyEvent.KEYCODE_DEL) {
                                text3.setEnabled(true);
                                text3.requestFocus();
                                text4.setEnabled(false);
                                text3.setSelection(text3.length());
                            }
                        }
                        if (editable.length() == 1){
                            if(i32== KeyEvent.KEYCODE_NUM) {
                                //OTP call API  here
                            }
                        }

                        return false;
                    });
                }
            });
    }
}